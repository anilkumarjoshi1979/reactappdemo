import { of } from 'rxjs/observable/of';
import { _throw } from 'rxjs/observable/throw';
import Configuration from '../config';
import user from '../constants/constants';

let apiCalls = {};

export const registerApiCall = (url, returnObject) => {
    apiCalls[url] = returnObject;
};

export const getJSON = (url) => {
    const newUrl = url.split('?date')[0];
    const mockResult = apiCalls[newUrl];
    if (mockResult && mockResult.isError) {
        return _throw(mockResult);
    }
    if (mockResult) {
        return of(mockResult);
    }
    return _throw("errorMessage");

    // return of();
};

export const postJSON = (url) => {
    const newUrl = url.split('?date')[0];
    const mockResult = apiCalls[newUrl];
    if (mockResult) {
        return of(mockResult);
    }
    return _throw('errorMessage');
};

export const put = (url) => {
    const newUrl = url.split('?date')[0];
    const mockResult = apiCalls[newUrl];

    if (mockResult) {
        return of(mockResult);
    }
    return _throw("errorMessage");

    // return of();
};

export const fetchPredictions = (autocompleteService, query) => {
    const addressObject = [{
        description: 'Bangarapet, Karnataka, India',
        id: '7496e1dc83b719d83d1f64dcacc1b0592bc1149b',
        structured_formatting: {
            main_text: 'Bangarapet',
            secondary_text: 'Karnataka, India',
        },
        types: [
            'locality',
            'political',
            'geocode',
        ],
    },
    {
        description: 'bangalore, Karnataka, India',
        id: '7496e1dc83b719d83d1f64dcacc1b0592bc114nbn',
        structured_formatting: {
            main_text: 'bangalore',
            secondary_text: 'Karnataka, India',
        },
        types: [
            'locality',
            'political',
            'geocode',
        ],
    }];
    return of(addressObject);
};

export const mockLoginData = () => {
    registerApiCall(`${Configuration.IDENTITY_BASE_URL}/token`, { token: 'token' });
    registerApiCall(`${Configuration.PLATFORM_API_BASE_URL}/accounts`, [{ id: '1394596166886NC52ZI5', name: 'TJ Buss', status: 'Active' }]);
    registerApiCall(`${Configuration.IDENTITY_BASE_URL}/userDetail`, user.userDetail);
    registerApiCall(`${Configuration.PLATFORM_API_BASE_URL}/identity`, {
        user: user.platformuser,
        account: { id: '1394596166886NC52ZI5', name: 'TJ Buss', status: 'Active' },
    });
    registerApiCall(`${Configuration.PLATFORM_API_BASE_URL}/users/65802`, user.platformuser);
    registerApiCall(`${Configuration.FLEET_VIEW_SERVICES_URL}/grails/home/signin`, { response: user.grailsRes });
    registerApiCall(`${Configuration.FLEET_VIEW_SERVICES_URL}/grails/home/signinToAccount?grailsRefId=${user.grailsRes.grailsRefId}`, { response: { message: 'login' } });
    registerApiCall(`${Configuration.FLEET_VIEW_SERVICES_URL}/grails/extJs/userSettings?grailsRefId=${user.grailsRes.grailsRefId}`, user.userSettings);
};

export const clearMocks = () => {
    apiCalls = {};
};
