import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';
import '../../src/index.scss';
import Routes from '../../src/constants/Routes';
import store from './constants/integrationTestStore';
import analytics from '../../src/analytics';
import ConfigService from '../../src/constants/Config';
import configuration from './config';

ConfigService.setConfig(configuration);
analytics.init();

export default () => (
    <Provider store={store()}>
        <Router>
            <Routes />
        </Router>
    </Provider>
);
