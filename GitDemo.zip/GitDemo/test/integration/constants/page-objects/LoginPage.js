import BasePageObject from './BasePageObject';

export default class extends BasePageObject {
    loginButton() {
        return this.byDataQa('login-submit-button');
    }

    forgotPasswordButton() {
        return this.byDataQa('forgot-password');
    }

    usernameInput() {
        return this.byDataQa('username');
    }

    passwordInput() {
        return this.byDataQa('password');
    }

    errorMessage() {
        return this.checkIsPresent('errorMessage') !== undefined;
    }

    login(username, password) {
        this.setValue(this.usernameInput(), username);
        this.setValue(this.passwordInput(), password);
        this.submit(this.loginButton());
    }
}
