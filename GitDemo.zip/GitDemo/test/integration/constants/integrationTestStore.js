import { applyMiddleware, createStore } from 'redux';
import { createEpicMiddleware } from 'redux-observable';
// rxJs observables
import { of } from 'rxjs/observable/of';
// rxJS operators
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/takeUntil';
import 'rxjs/add/operator/retry';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import reducers from '../../../src/reducers';
import epics from '../../../src/epics';
import { getJSON, postJSON, put, fetchPredictions } from '../utils/api-mock';


export default () => createStore(reducers, applyMiddleware(createEpicMiddleware(epics, {
    dependencies: {
        getJSON,
        postJSON,
        put,
        fetchPredictions,
        of,
    },
})));
