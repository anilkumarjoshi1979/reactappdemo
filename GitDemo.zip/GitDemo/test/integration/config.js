const Configuration = {
    REACT_APP_APP_TOKEN: 'deac4c6c-81f1-11e7-bb31-be2e44b06b34',
    IDENTITY_BASE_URL: 'http://amw1identity1.com',
    PLATFORM_API_BASE_URL: 'http://services.stage/v0/rest',
    NEWRELIC_LICENSE: 'ccb659c163',
    NEWRELIC_APPLICATION: '76200465',
    DEBOUNCE_TIME: 1000,
    GOOGLE_MAPS_BASE_URL: 'https://maps.googleapis.com/maps/api',
    GOOGLE_MAPS_API_KEY: 'AIzaSyB7lt46kn6IIHLQbUO9I0L2opcMYSi-ATs',
    FLEET_VIEW_SERVICES_URL:
        'http://a1dd7f2907e2a11e8b03402141b956cb-1688648457.us-east-2.elb.amazonaws.com:8080/api',
    TRIPS_API_BASE_URL:
        'http://a85a059f2cb1011e8b03402141b956cb-515504380.us-east-2.elb.amazonaws.com:8080/api',
};

export default Configuration;
