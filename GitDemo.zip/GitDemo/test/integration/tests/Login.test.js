import LoginPage from '../page-objects/LoginPage';
import { registerApiCall, clearMocks, mockLoginData } from '../utils/api-mock';
import Configuration from '../config';
import user from '../constants/constants';

const { user: { username, password } } = user;

describe('Login page functionality', () => {
    let app;

    beforeEach(() => {
        clearMocks();
        app = new LoginPage();
    });

    it('should show error when both username and password are not entered', async () => {
        // Execute
        await app.submit(app.loginButton());
        // Validate
        expect(app.errorMessage()).toBe(true);
        expect(app.currentRoute()).toEqual('/login');
    });

    it('should show error when no password entered', async () => {
        // Execute
        await app.setValue(app.usernameInput(), ('username'));
        await app.submit(app.loginButton());
        // Validate
        expect(app.errorMessage()).toBe(true);
        expect(app.currentRoute()).toEqual('/login');
    });

    it('should show error when username not entered', async () => {
        // Execute
        await app.setValue(app.usernameInput(), ('password'));
        await app.submit(app.loginButton());
        // Validate
        expect(app.errorMessage()).toBe(true);
        expect(app.currentRoute()).toEqual('/login');
    });

    it('should navigate to homeSearchBox page and save userToken to local storage on login success', () => {
        // Setup
        mockLoginData();
        // Execute
        app.login(username, password);
        // Validate
        expect(localStorage.getItem('userToken')).toEqual('token');
        expect(app.currentRoute()).toEqual('/home');
    });

    it('should show the error message when wrong credentials are entered', async () => {
        // Setup
        await registerApiCall(`${Configuration.IDENTITY_BASE_URL}/token`, null);
        // Execute
        await app.login(username, password);
        // Validate
        expect(app.currentRoute()).toEqual('/login');
        expect(app.errorMessage()).toBe(true);
    });
});
