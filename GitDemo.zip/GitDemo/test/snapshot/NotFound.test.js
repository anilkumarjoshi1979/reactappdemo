import React from 'react';
import { Link } from 'react-router-dom';
import { StaticRouter } from 'react-router'
import renderer from 'react-test-renderer';
import NotFound from '../../src/components/SearchResults/NotFound/NotFound';

it('NotFound Component:renders correctly', () => {
    const component = renderer.create(
        <StaticRouter location="/home" context={ {} }> 
       <NotFound />
        </StaticRouter>
      );

    const tree = component
        .toJSON();
    expect(tree).toMatchSnapshot();
});

