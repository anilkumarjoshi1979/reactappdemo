import React from 'react';
import renderer from 'react-test-renderer';
import LoginForm from '../../src/components/LoginForm/LoginForm';
import logo from '../../src/assets/logo.png';

it('LoginForm:renders correctly', () => {
    const tree = renderer
        .create(<LoginForm
            logoSrc={logo}
            inValidUser
            handleSubmit={() => {}}
            redirectToForgotPassWord={() => {}}
        />)
        .toJSON();
    expect(tree).toMatchSnapshot();
});
