test('login form', () => {
        const driver = createDriver(System.getProperty("baseUrl") || 'localhost:3000',
            System.getProperty("resolution") || '1920x1080',
            System.getProperty("browser") || 'chrome');

        const pageSpec = parsePageSpec({
            driver: driver,
                spec: "test/layout/specs/login.page.gspec",
            tags: ["desktop"]
        });

        checkPageSpecLayout(driver, pageSpec, ["all", "desktop"]);

    // Destroy the session
    driver.quit();
});
