this.LandmarkGroup = function (driver) {
    GalenPages.extendPage(this, driver, "Landmark Group page", {

        landmarkGroupHeader: "id :landmark-group-header",
        firstListItem: "id : landmark0",
        searchIcon: "id : search-btn",
        filterIcon: "id : filter-btn",

        goToLandmarkGroup: function (groupId) {
            //todo : this wait need to be optimise in login page
            GalenPages.sleep(10000);
            this.open("http://localhost:3000/landmark-group/"+groupId);
            return this.waitForIt();
        },

        openSearchBox: function (searchString) {
            this.searchIcon.click();
            this.searchBox.typeText(searchString);
        },


    },{
        // secondary fields
        // will not part of this.waitForIt()
        searchBox: "id : search-box",
    });
};
