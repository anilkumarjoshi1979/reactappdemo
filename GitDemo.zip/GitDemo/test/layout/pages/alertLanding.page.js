this.AlertTypes = function (driver) {
    GalenPages.extendPage(this, driver, "Alert Types", {
	alerts: "id: Alerts",
	alerttypes: "id:AlertTypes",
	Hardbreaking_acceleration_alert_hover: "id: hvrHardBreakingAccelerationAlert",
	Odd_hours_alert_hover: "id: hvrOddHoursAlert",       
	posted_speed_limit_alert_hover: "id: hvrPostedSpeedLimitAlert",       
	speed_threshold_alert_hover: "id: hvrSpeedThresholdAlert",       
	Unauthorised_movement_alert_hover: "id: hvrUnauthorizedMovement",    
	Seatbelt_status_alert_hover: "id: hvrSeatbeltStatusAlert",       
	Idle_alert_hover: "id: hvrIdleAlert",       
	Stop_alert_hover: "id: hvrStopAlert",       
	Input_alert_hover: "id: hvrInputAlert",       
	Landmark_arrival_alert_hover: "id: hvrLandmarkArrivalDepartureAlert",       
	Device_Power_Connect_alert_hover: "id: hvrDevicePowerConnectAlert",        
	Device_Power_Disconnect_alert_hover: "id: hvrDevicePowerDisconnectAlert",      
	Temperature_alert_hover: "id: hvrTemperatureAlert",       
	Fuel_Tank_alert_hover: "id: hvrFuelTankAlert",              
	Low_battery_alert_hover: "id: hvrLowAssetBatteryAlert",
	Tire_pressure_alert_hover: "id: hvrTirePressureAlert",        
	Engine_oil_life_alert_hover: "id: hvrEngineOilLifeAlert",

        waitForLoadHomePage: function () {
            return this.waitForIt();
        },
        
        goToAlertTypes: function () {
            this.alerts.click();
            this.alerttypes.click();
        },
        goToHardbreaking_acceleration_alert_hover: function () {
            this.Hardbreaking_acceleration_alert_hover.hover();
        },
        goToOdd_hours_alert_hover: function () {
            this.Odd_hours_alert_hover.hover(); 
        },                
        goToposted_speed_limit_alert_hover: function () {
             this.posted_speed_limit_alert_hover.hover();
        },       
        goTospeed_threshold_alert_hover: function () {
            this.speed_threshold_alert_hover.hover();
        },          
        goToUnauthorised_movement_alert_hover: function () {
            this.Unauthorised_movement_alert_hover.hover();
        },    
        goToSeatbelt_status_alert_hover: function () {
            this.Seatbelt_status_alert_hover.hover();
        },          
        goToIdle_alert_hover: function () {
            this.Idle_alert_hover.hover();
        },                     
        goToStop_alert_hover: function () {
            this.Stop_alert_hover.hover();
        },                     
        goToInput_alert_hover: function () {
            this.Input_alert_hover.hover();
        },                    
        goToLandmark_arrival_alert_hover: function () {
            this.Landmark_arrival_alert_hover.hover();
        },                
        goToDevice_Power_Connect_alert_hover: function () {
            this.Device_Power_Connect_alert_hover.hover();
        },       
        goToDevice_Power_Disconnect_alert_hover: function () {
            this.Device_Power_Disconnect_alert_hover.hover();
        },     
        goToTemperature_alert_hover: function () {
            this.Temperature_alert_hover.hover();
        },              
        goToFuel_Tank_alert_hover: function () {
            this.Fuel_Tank_alert_hover.hover();
        },                
        goToLow_battery_alert_hover: function () {
            this.Low_battery_alert_hover.hover();
        },              
        goToTire_pressure_alert_hover: function () {
            this.Tire_pressure_alert_hover.hover();
        },            
        goToEngine_oil_life_alert_hover: function () {
            this.Engine_oil_life_alert_hover.hover();
        },
    }, {
        mtAccountsBtn: "id: my-account",
    });
};
