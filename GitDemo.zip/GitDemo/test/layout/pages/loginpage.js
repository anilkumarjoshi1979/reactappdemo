this.LoginPage = function (driver) {
  GalenPages.extendPage(this, driver, "Login page", {
    usernameField: "id: username",
    passwordField: "id: password",
    submitButton: "id: signInBtn",

    load: function () {
      this.open("http://localhost:3000/login");
      return this.waitForIt();
    },
    login: function () {
      this.usernameField.typeText("tjbussfl");
      this.passwordField.typeText("123456");
      this.submitButton.click();
      this.homeScreenAccountBtn.waitToBeShown("15s");

    }
  }, {
      // secondary fields
      // will not part of this.waitForIt()
      homeScreenAccountBtn: "id : account_settings",
  });
};
