this.AddressDetailsPage = function (driver) {
    GalenPages.extendPage(this, driver, "Address details page", {
        addressDetailsContainer: "id: address-details-container",
        addressHeader: "id: address-header",
        addressSubHeader: "id: sub-header",
        nearestAsset: "id: btn-nearest-asset",
        addLandmark: "id: btn-add-landmark",

        waitForPageToLoad: function () {
            return this.waitForIt();
        },

    });
};
