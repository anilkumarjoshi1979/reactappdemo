this.AssetGroup = function (driver) {
    GalenPages.extendPage(this, driver, "Asset Group page", {

        assetGroupSidebarContainer: "id :asset-group-details",
        firstListItem: "id : asset-list-item",
        searchIcon: "id : search-btn",
        filterIcon: "id : filter-btn",

        goToAsssetGroupList: function (assetId) {
            this.open("http://localhost:3000/asset-group/"+assetId);
            return this.waitForIt();
        },

        openSearchBox: function (searchString) {
            this.searchIcon.click();
            this.searchBox.typeText(searchString);
        },

    })
};
