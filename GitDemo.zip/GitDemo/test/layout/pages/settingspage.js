this.SettingsPage = function (driver) {
    GalenPages.extendPage(this, driver, "Home page", {
        appSettingsTab: "id: account_settings",
        mtAccountsBtn: "id: my-account",
        navAppSettings: "id: nav-app-settings",
        navChangePassword: "xpath: //div[@data-qa='account_password_tab']",
        saveChanges: "id: save-changes",

        goToSettings: function () {
            this.waitForIt();
            this.accountBtn.waitToBeShown();
            this.accountBtn.click();
            this.mtAccountsBtn.waitToBeShown();
            this.mtAccountsBtn.click();
        },

        openAccountPopup: function () {

            GalenPages.sleep(30000);
            this.accountBtn.waitToBeShown();
            this.accountBtn.click();
            GalenPages.sleep(3000);
        }
    });
};
