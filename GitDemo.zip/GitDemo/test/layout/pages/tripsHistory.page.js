this.TripsHistory = function (driver) {
    GalenPages.extendPage(this, driver, "Trips History page", {
      headerCard: "id: header-card",
      backButton: "xpath: //*[@id='header-card']/div/div/button",
      assetTitle: "id: Asset-Name",
      assetSubTitle: "id: sub-header",  
      tripsList: "id: trips-list",
      firstTrip: "id: trip-0"
      
  
    }, {
        // secondary fields
        // will not part of this.waitForIt()
        homeScreenAccountBtn: "id : account_settings",
    });
  };
  