this.HomePage = function (driver) {
    GalenPages.extendPage(this, driver, "Home page", {
        accountBtn: "xpath: //*[@id='account_settings']",
        searchBox: "id: search-box",

        waitForLoadHomePage: function () {
            GalenPages.sleep(10000);
            return this.waitForIt();
        },
        landmarks: "id: Landmarks",
        assets: "id: Assets",
        mapOption: "xpath: //*[@data-type='map']",
        historyOption: "xpath: //*[@data-type='History']",
        
        goToSettings: function () {
            GalenPages.sleep(3000);
            this.accountBtn.waitToBeShown();
            this.accountBtn.click();
            GalenPages.sleep(3000);
            this.mtAccountsBtn.waitToBeShown();
            this.mtAccountsBtn.click();
            GalenPages.sleep(3000);
        },

        openAccountPopup: function () {
            GalenPages.sleep(3000);
            this.accountBtn.waitToBeShown();
            this.accountBtn.click();
            GalenPages.sleep(3000);
        },

        goToLandmarkDetails: function (searchKeyWord) {
            this.searchBox.waitToBeShown();
            this.searchBox.typeText(searchKeyWord);
            this.landmarks.waitToBeShown();
            this.landmarks.click();
            this.mapOption.waitToBeShown();
            this.mapOption.click();
        },

        goToAddressDetails: function (searchKeyWord) {
            GalenPages.sleep(3000);
            this.searchBox.waitToBeShown();
            this.searchBox.typeText(searchKeyWord);
            this.addresses.waitToBeShown();
            this.addresses.click();
            this.mapOption.waitToBeShown();
            this.mapOption.click();
        },

        goToAssetDetails: function (searchKeyWord) {
            this.searchBox.waitToBeShown();
            this.searchBox.typeText(searchKeyWord);
            this.assets.waitToBeShown();
            this.assets.click();
            this.mapOption.waitToBeShown();
            this.mapOption.click();
            GalenPages.sleep(3000);
        },

        goToAssetHistory: function (searchKeyWord) {
            this.searchBox.waitToBeShown();
            this.searchBox.typeText(searchKeyWord);
            this.assets.waitToBeShown();
            this.assets.click();
            this.historyOption.waitToBeShown();
            this.historyOption.click();
            GalenPages.sleep(3000);
        },
    }, {
        mtAccountsBtn: "id: my-account",
        landmarks: "id: Landmarks",
        addresses: "id: Addresses",
        mapOption: "xpath: //*[@id='map-option-0']", //just tried with xpath
    });
};
