This project utilizes Galen framework for layout testing

**Galen Framework**: http://galenframework.com/

**Example Test Run using NPM**
**Stage**
npm run galen -- test test/layout/tests/loginTest.js -DbaseUrl=http://fleetpwa-stage.spireon.com/

**Local**
npm run galen -- test test/layout/tests/loginTest.js

**Example Page Dump**
./node_modules/.bin/galen dump --url "http://fleetpwa-stage.spireon.com/" --export "dumps/login-dump" --max-width "200" --max-height "200" --size "1920x1080" --config "test/layout/.galen.config"  test/layout/specs/login.page.gspec