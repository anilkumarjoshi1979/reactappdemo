/* @flow */

export const SAMPLE_TRIPS = [
  {
    "id" : "5124_4136933_1532989730",
    "assetId" : "3511087",
    "startDate" : "2018-07-30T16:58:50.000+0000",
    "endDate" : "2018-07-30T17:24:50.000+0000",
    "durationInMins" : 26,
    "distance" : 21374,
    "locationBegin" : {
      "latitude" : 33.98447,
      "longitude" : -85.2544838,
      "address" : {
        "line1" : "Industrial Dr",
        "state" : "GA",
        "city" : "Rockmart",
        "zipCode" : "30153"
      }
    },
    "locationEnd" : {
      "latitude" : 34.0163435,
      "longitude" : -85.0645141,
      "address" : {
        "line1" : "Industrial Dr",
        "state" : "GA",
        "city" : "Rockmart",
        "zipCode" : "30153"
      }
    },
    "alerts" : {
      "IDLE" : 1,
      "ODD_HOURS" : 1,
      "SPEED_THRESHOLD" : 3
    }
  }
];

export const SAMPLE_ASSET_SEARCH_RESULT = {
    "content": {
      "searchTerm": "0006",
      "total": 1,
      "assets": {
        "data": [
          {
            "id": "1518133293875ZKK0WAB",
            "name": "0006",
            "type": "asset.type.localFleet.vehicle.light",
            "accountId": "1394596166886NC52ZI5",
            "assetGroupId": "f1a5c80f-62bc-4e5d-b8a4-c2d5368a2489",
            "assetGroupName": "Sub_2.20",
            "deviceSerialNumber": "4674030493",
            "active": false,
            "status": "Idle",
            "speed": 0,
            "seatBeltStatus": false,
            "locationLastReported": 1567983450827,
            "lastLocation": {
              "x": -83.010788,
              "y": 40.1346207
            }
          }
        ],
        "count": 1,
        "total": 1
      },
      "assetGroups": {
        "data": [],
        "count": 0,
        "total": 0
      },
      "landmarks": {
        "data": [],
        "count": 0,
        "total": 0
      },
      "landmarkGroups": {
        "data": [],
        "count": 0,
        "total": 0
      },
      "drivers": {
        "data": [],
        "count": 0,
        "total": 0
      }
    }
  }

  export const TRIP_DETAIL_RESULT = {
    "id" : "5b62d8bcc3da240e729badd5",
    "tripId" : "5124_4136933_1532989730",
    "type" : "IGN_ON",
    "date" : "2018-08-02T04:36:50.000+0000",
    "speed" : 0,
    "heading" : "E",
    "voltage" : 0.0,
    "rssi" : 0,
    "satellite" : 0,
    "asset" : {
      "id" : "3511087",
      "name" : "AssetName",
      "type" : "Vehicle-Light Duty"
    },
    "operator" : {
      "id" : "123",
      "firstName" : "Frank",
      "lastName" : "Drivenheimer",
      "nickName" : ""
    },
    "landMark" : {
      "id" : "landMark123",
      "name" : "landMark"
    },
    "distance" : 242,
    "durationInMins" : 0,
    "location" : {
      "latitude" : 34.2878692,
      "longitude" : -86.2155037,
      "address" : {
        "line1" : "Csx RR",
        "state" : "AL",
        "city" : "Albertville",
        "zipCode" : "35950"
      }
    },
    "alerts" : [ ]
  }