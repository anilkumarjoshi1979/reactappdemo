/*
* Error messages used in the e2e test
*/
const {
    CONSTANTS: {
        FORGOT_PASSWORD_FORM, GLOBAL_SEARCH, LOGINFORM, RESET_PASSWORD_FORM,
    },
} = require('../../src/constants/constants');

exports.CONSTANTS = {
    CHANGE_PASSWORD_TEST: {
        PASSSWORD_CHANGED_SUCCESSFULY: 'Password has been updated successfully.',
        INVITATION_IS_EXPIRED: 'Invitation is expired',
    },

    TEST_DATA: {
        VALId_USER: 'testingimap09@gmail.com',
        INVALID_USER: 'test',
        USER_NAME_WITH_MORE_THAN_LIMIT: 'The Android App Bundle is Android\'s new app publishing format. It means a smaller app for your users and a streamlined, more efficient release process for you. The app bundle also introduces modularization so you can deliver dynamic features on demand and increase discovery with Google Play Instant.',
        LEFT_MENU_ITEMS: ['Home', 'List', 'Reports', 'Alerts', 'Admin'],
    },

    FORGOT_PASSWORD_FORM,
    GLOBAL_SEARCH,
    LOGINFORM,
    RESET_PASSWORD_FORM,
};

exports.baseurls = {
    platform: 'https://fleet-view-services-stage.spireon.com',
};

exports.listColumns = {
    assets: [
        { columnKey: 'name', columnName: 'Name' },
        { columnKey: 'id', columnName: 'Asset ID' },
        { columnKey: 'type', columnName: 'Asset Type' },
        { columnKey: 'address', columnName: 'Address' },
        { columnKey: 'city', columnName: 'City' },
        { columnKey: 'stateOrProvince', columnName: 'State' },
        { columnKey: 'zipCode', columnName: 'Zip Code' },
        { columnKey: 'driver', columnName: 'Driver' },
        { columnKey: 'engineHours', columnName: 'Engine Hours' },
        { columnKey: 'status', columnName: 'Status' },
        { columnKey: 'extVolt', columnName: 'Ext Volt' },
        { columnKey: 'assetGroupName', columnName: 'Group Name' },
        { columnKey: 'inputStatus', columnName: 'Input Status' },
        { columnKey: 'intVolt', columnName: 'Int Volt' },
        { columnKey: 'lastEvent', columnName: 'Last Event' },
        { columnKey: 'lastEventDate', columnName: 'Last Event Date' },
        { columnKey: 'location', columnName: 'Location' },
        { columnKey: 'latitude', columnName: 'Latitude' },
        { columnKey: 'logitude', columnName: 'Longitude' },
        { columnKey: 'make', columnName: 'Make' },
        { columnKey: 'model', columnName: 'Model' },
        { columnKey: 'vin', columnName: 'VIN' },
        { columnKey: 'year', columnName: 'Year' },
        { columnKey: 'odometer', columnName: 'Odometer / Total Mileage' },
        { columnKey: 'oilLifeRemaining', columnName: 'Oil Life Remaining' },
        { columnKey: 'seatBeltStatus', columnName: 'Seatbelt Status' },
        { columnKey: 'deviceSerialNumber', columnName: 'Serial Number' },
        { columnKey: 'speed', columnName: 'Speed' },
        { columnKey: 'statusStartDate', columnName: 'Status Duration' },
        { columnKey: 'tags', columnName: 'Tags' },
        { columnKey: 'cargoTemperature', columnName: 'Temperature (F)' },
        { columnKey: 'tirePressure', columnName: 'Tire Pressure' },
        { columnKey: 'direction', columnName: 'Heading' },
        { columnKey: 'attributes', columnName: 'Custom Attributes' }       
    ],

    landmarks: [
        { columnKey: 'name', columnName: 'Name' },
        { columnKey: 'landmarkGroupName', columnName: 'Group Name' },
        { columnKey: 'totalAssets', columnName: 'Assets Present' },
        { columnKey: 'description', columnName: 'Description' },
        { columnKey: 'phoneNumber', columnName: 'Phone Number' },
        { columnKey: 'address', columnName: 'Address' },
        { columnKey: 'latitude', columnName: 'Latitude' },
        { columnKey: 'logitude', columnName: 'Longitude' },
        { columnKey: 'shape', columnName: 'Shape' },
        { columnKey: 'dateCreated', columnName: 'Created Date' },
        { columnKey: 'customAttributes', columnName: 'Custom' }
    ],

    // scorecard: [
    //     { columnKey: 'name', columnName: 'Name' },
    //     { columnKey: 'landmarkGroupName', columnName: 'Group Name' },
    //     { columnKey: 'totalAssets', columnName: 'Assets Present' },
    //     { columnKey: 'description', columnName: 'Description' },
    //     { columnKey: 'phoneNumber', columnName: 'Phone Number' },
    //     { columnKey: 'address', columnName: 'Address' },
    //     { columnKey: 'latitude', columnName: 'Latitude' },
    //     { columnKey: 'logitude', columnName: 'Longitude' },
    //     { columnKey: 'shape', columnName: 'Shape' },
    //     { columnKey: 'dateCreated', columnName: 'Created Date' },
    //     { columnKey: 'customAttributes', columnName: 'Custom' }
    // ],


    assetGroups: [
        { columnKey: 'name', columnName: 'Group Name' },
        { columnKey: 'directAssetsCount', columnName: 'Direct Vehicles' },
        { columnKey: 'indirectAssetsCount', columnName: 'Indirect Vehicles' },
        { columnKey: 'totalAssetsCount', columnName: 'Total Vehicles' }
    ],

    landmarkGroups: [
        { columnKey: 'name', columnName: 'Name' },
        { columnKey: 'directLandmarkCount', columnName: 'Direct Landmarks' },
        { columnKey: 'indirectLandmarkCount', columnName: 'Indirect Landmarks' },
        { columnKey: 'totalLandmarkCount', columnName: 'Total Landmarks' }
    ]
};
