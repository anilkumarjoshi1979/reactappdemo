// rxJS operators
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/takeUntil';
import 'rxjs/add/operator/retry';
import 'rxjs/add/operator/toArray';
import 'rxjs/add/operator/toPromise';

// Mock global btoa function
global.btoa = string => string;
