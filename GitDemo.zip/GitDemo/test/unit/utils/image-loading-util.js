import assetImage from '../assets/icons/assets/truck.svg';
