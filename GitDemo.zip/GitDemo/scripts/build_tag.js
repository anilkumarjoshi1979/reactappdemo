var fs = require('fs');
var getRepoInfo = require('git-repo-info');
var package = require('../package.json');

var buildFileName = 'public/build_tag.js';

var info = getRepoInfo();

if (info.sha) {
    write(info);
}

function write(obj) {
	obj = obj || {};
	obj.timestamp = new Date();
	obj.version = package.version;
    var str = 'window.FLEET_APP_BUILD_TAG=' + JSON.stringify(obj);
    fs.writeFile(buildFileName, str, function(err) {
        if (err) {
            return console.log('Error writing build_tag file', err);
        }
        console.log('Done writing build_tag', obj);
    });

}
