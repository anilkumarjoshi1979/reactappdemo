import React, {Component} from 'react';
import {MainLayout} from "../../layouts/MainLayout";

export class Admin extends Component {
    render() {
        return (
            <MainLayout>
                <h2>Admin Page</h2>
            </MainLayout>
        );
    }
}
