// add all new HOCs here to export
export {default as reduxConnect} from './ReduxConnect';
