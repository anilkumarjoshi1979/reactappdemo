import React, { Component } from 'react';

function NotFoundComponent (){
	return <h1>404 - Sorry this page is not found</h1>
}

export default NotFoundComponent;
